///variables globales
let tablePro = document.querySelector("#table-pro > tbody");
let searchInput = document.querySelector("#search-input");
let nameUser = document.querySelector("#nombre-usuario");
let btnLogout = document.querySelector("#btnLogout");

//funcion para poner el nombre del usuario
let getUser = () => {
    let user = JSON.parse(localStorage.getItem("userLogin"));
    nameUser.textContent = user.nombre;
};

//evento al boton de cerrar sesion
btnLogout.addEventListener("click",()=>{
    localStorage.removeItem("userLogin");
    location.href = "../login.html";
});
//evento para probar el campo buscar
searchInput.addEventListener("keyup", () => {
   console.log(searchInput.value);
})

//evento para el navegador
document.addEventListener("DOMContentLoaded", () => {
    getTableData();
    getUser();
})

//funcion para traer los datos de BD a la tabla
let getTableData = async ()=>{
    let url = " http://localhost/backend-apiCrud/productos";
    try {
        let respuesta = await fetch(url,{
            method: "GET",
            headers: {
                "Content-Type": "application/json"
            },
        });
        if (respuesta.status === 204){
           console.log("no hay datos en la DB");

        }else{
            let getTableData = await respuesta.json();
            console.log(getTableData);

             //agregar los datos de la tabla a localStorage
             localStorage.setItem("datosTabla", JSON.stringify(getTableData));
            //agregar los datos a la tabla
            getTableData.forEach((dato,i) => {
                let row = document.createElement("tr");
                row.innerHTML = `
                    <td> ${i} </td>
                    <td> ${dato.nombre} </td>
                    <td> ${dato.descripcion} </td>
                    <td> ${dato.precio} </td>
                    <td> ${dato.stock} </td>
                    <td> <img src = "${dato.imagen}" width = "100px"> </td>
                    <td> 
                        <button id= "btn-edit"  onclick = "editDataTable(${i})" type="button" class="btn btn-warning">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
                        <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
                        <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5z"/>
                        </svg>                        
                        </button> -
                        ${ nameUser.textContent == "vendedor" ? "":
                        `
                         <button  id= "btn-delete" onclick = "deleteDataTable(${i})" type="button" class="btn btn-danger">
                         <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash3" viewBox="0 0 16 16">
                         <path d="M6.5 1h3a.5.5 0 0 1 .5.5v1H6v-1a.5.5 0 0 1 .5-.5M11 2.5v-1A1.5 1.5 0 0 0 9.5 0h-3A1.5 1.5 0 0 0 5 1.5v1H1.5a.5.5 0 0 0 0 1h.538l.853 10.66A2 2 0 0 0 4.885 16h6.23a2 2 0 0 0 1.994-1.84l.853-10.66h.538a.5.5 0 0 0 0-1zm1.958 1-.846 10.58a1 1 0 0 1-.997.92h-6.23a1 1 0 0 1-.997-.92L3.042 3.5zm-7.487 1a.5.5 0 0 1 .528.47l.5 8.5a.5.5 0 0 1-.998.06L5 5.03a.5.5 0 0 1 .47-.53Zm5.058 0a.5.5 0 0 1 .47.53l-.5 8.5a.5.5 0 1 1-.998-.06l.5-8.5a.5.5 0 0 1 .528-.47M8 4.5a.5.5 0 0 1 .5.5v8.5a.5.5 0 0 1-1 0V5a.5.5 0 0 1 .5-.5"/>
                         </svg>
                         </button>`}
                    </td>



                `;
                tablePro.appendChild(row);
            });
        
        }
    }
    catch (error) {
        console.log(error);
    }    
    searchProducTable();
        
}

//funcion para  editar algun producto de la tabla
let editDataTable = (pos) =>{
    let products = [];
    let productsSave = JSON.parse(localStorage.getItem("datosTabla"))
    if(productsSave != null){
        products = productsSave;
    }
    let singleProducts = products[pos];
    //console.log(singleProducts)
    localStorage.setItem("ProductsEditar", JSON.stringify(singleProducts))
    localStorage.removeItem("datosTabla");
    location.href = "../crear pro.html"
}

//funcion para  eliminar algun producto de la tabla
let deleteDataTable = (pos) =>{
    let products = [];
    let productsSave = JSON.parse(localStorage.getItem("datosTabla"))
    if(productsSave != null){
    products = productsSave;
    }
    let singleProducts = products[pos];
    let IDProduct ={
        id:singleProducts.id
    }
    let confirmar = confirm(`¿Deseas eliminar ${singleProducts.nombre}?`);
    if(confirmar){
        //llmar la funcion para realizar la peticion
        sendDeleteProduct( IDProduct );
    }
    
}

//funcion para realizar la peticion de eliminar un producto
let sendDeleteProduct = async(id)=>{
    let url = "http://localhost/backend-apiCrud/productos"; // Corregí "ulr" a "url"
    try {
        let respuesta = await fetch(url,{
            method: "DELETE",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(id)
        });
        if (respuesta.status === 406){
            alert("El ID enviado no fue admitido");

        }else{
            let mensaje = await respuesta.json();
            alert(mensaje.message);       
            location.reload();
        }
    }
    catch (error) {
        console.log(error);
    }    
}

//funcion para quitar productos de la lista
let clearDataTble = ()=>{
    let rowTable = document.querySelectorAll("#table-pro > tbody > tr");
    rowTable.forEach((row)=>{
        row.remove();
    });
}

//Funcion para buscar un producto de la tabla
let searchProducTable = ()=>{
    let products = [];
    let productsSave = JSON.parse(localStorage.getItem("datosTabla"))
    if(productsSave != null){
        products = productsSave;
        
    }
    
    //obtener lo escrito en el campo de texto
    let textSearch = searchInput.value.toLowerCase();
    clearDataTble();
    let i = 0;
    for (let pro of products) {
        //comprobar coincidencia de los productos
        if (pro.nombre.toLowerCase().indexOf(textSearch) != -1){
            let row = document.createElement("tr");
            row.innerHTML = `
                <td> ${i+1} </td>
                <td> ${pro.nombre} </td>
                <td> ${pro.descripcion} </td>
                <td> ${pro.precio} </td>
                <td> ${pro.stock} </td>
                <td> <img src = "${pro.imagen}" width = "100px"> </td>
                <td> 
                    <button id= "btn-edit"  onclick = "editDataTable(${i})" type="button" class="btn btn-warning">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
                    <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
                    <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5z"/>
                    </svg>                        
                    </button> -
                    ${ nameUser.textContent == "vendedor" ? "":
                    `
                     <button  id= "btn-delete" onclick = "deleteDataTable(${i})" type="button" class="btn btn-danger">
                     <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash3" viewBox="0 0 16 16">
                     <path d="M6.5 1h3a.5.5 0 0 1 .5.5v1H6v-1a.5.5 0 0 1 .5-.5M11 2.5v-1A1.5 1.5 0 0 0 9.5 0h-3A1.5 1.5 0 0 0 5 1.5v1H1.5a.5.5 0 0 0 0 1h.538l.853 10.66A2 2 0 0 0 4.885 16h6.23a2 2 0 0 0 1.994-1.84l.853-10.66h.538a.5.5 0 0 0 0-1zm1.958 1-.846 10.58a1 1 0 0 1-.997.92h-6.23a1 1 0 0 1-.997-.92L3.042 3.5zm-7.487 1a.5.5 0 0 1 .528.47l.5 8.5a.5.5 0 0 1-.998.06L5 5.03a.5.5 0 0 1 .47-.53Zm5.058 0a.5.5 0 0 1 .47.53l-.5 8.5a.5.5 0 1 1-.998-.06l.5-8.5a.5.5 0 0 1 .528-.47M8 4.5a.5.5 0 0 1 .5.5v8.5a.5.5 0 0 1-1 0V5a.5.5 0 0 1 .5-.5"/>
                     </svg>
                     </button>`}
                </td>
            `;
            tablePro.appendChild(row);
        }

        }
        
};
