// Variables globales del formulario de login
const d = document;
userInput = d.querySelector("#usuarioForm");
passInput = d.querySelector("#contraForm"); // Corregí el nombre
btnLogin = d.querySelector(".btnLogin");

// Evento al botón del formulario
btnLogin.addEventListener("click", () => {
    //alert("escribió: " + userInput.value);
    let dataForm = getData();
    sendData(dataForm);
});

// Función para validar el formulario y obtener datos del formulario
// obtener datos del formulario

let getData = () => {
    // Validar formulario
    let user;
    if (userInput.value && passInput.value) {
        user = {
            usuario: userInput.value,
            contrasena: passInput.value // Corregí "cotrasena" a "contraseña"
        };
        userInput.value = "";
        passInput.value = "";
    } else {
        alert("El usuario y la contraseña son obligatorios");
    }
    console.log(user);
    return user;
};

// Función para recibir los datos y realizar la petición al servidor
let sendData = async (data) => {
    let url = "http://localhost/backend-apiCrud/login"; // Corregí "ulr" a "url"
    try {
        let respuesta = await fetch(url,{
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(data)
        });
        if (respuesta.status === 401){
            alert("Usuario y/o contraseña incorrectos");

        }else{
            let userLogin = await respuesta.json();
        
        alert(`bienvenido: ${userLogin.nombre}`);
        //guardar datos en el local storage
        localStorage.setItem("userLogin", JSON.stringify(userLogin));
        location.href= "../index.html";
        }
    }
    catch (error) {
        console.log(error);
    }    
        

    
};
