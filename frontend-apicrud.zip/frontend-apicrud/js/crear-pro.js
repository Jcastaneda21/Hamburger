
//variables globales del formularioo

const d = document;
let nameInput = d.querySelector('#productos-select');
let priceInput = d.querySelector('#precio-pro');
let stockInput = d.querySelector('#stock-pro');
let descripcionInput = d.querySelector('#des-pro');
let imagen = d. querySelector('#imagen-pro');
let btnCreate = d.querySelector('.btn-create');
let ProductsUpdate;
let nameUser = d.querySelector("#nombre-usuario");
let btnLogout = d.querySelector("#btnLogout");

//funcion para poner el nombre del usuario
let getUser = () => {
    let user = JSON.parse(localStorage.getItem("userLogin"));
    nameUser.textContent = user.nombre;
};

//evento al boton de cerrar sesion
btnLogout.addEventListener("click",()=>{
    localStorage.removeItem("userLogin");
    location.href = "../login.html";
});

//evento al boton del formulario
btnCreate.addEventListener('click' , () =>{
    //alert("producto :" +nameInput.value);
    let dataProduct = getDataProduct();
    sendDataProduct (dataProduct)
    
})

// Evento al navegador para comprobar que recargo la pagina
d.addEventListener("DOMContentLoaded", ()=>{
    getUser();
ProductsUpdate = JSON.parse(localStorage.getItem("ProductsEditar"));
if(ProductsUpdate !=null){
    updateDataProducts
}
});
//funcion para validar el formulario y obtener los datos

let getDataProduct = () => {
    // Validar formulario
    let product;
    if (nameInput.value && priceInput.value && stockInput.value && descripcionInput.value && imagen.src) {
        product = {
            nombre: nameInput.value,
            descripcion: descripcionInput.value,
            precio: priceInput.value,
            stock: stockInput.value,
            imagen: imagen.src
          
        };
        priceInput.value = "";        
        descripcionInput.value = "";
        stockInput.value = "";
        imagen.src = "https://m.media-amazon.com/images/I/61XV8PihCwL._SY250_.jpg";
        console.log(product);


    } else {
        alert("Todos los campos son obligatorios");
    }
    
    return product;
};


let sendDataProduct = async (data) => {
    let url = "http://localhost/backend-apiCrud/productos"; // Corregí "ulr" a "url"
    try {
        let respuesta = await fetch(url,{
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(data)
        });
        if (respuesta.status === 406){
            alert("Los datos enviados no son admitidos");

        }else{
            let mensaje = await respuesta.json();
            alert(mensaje.message);       
            location.href = "../listado-pro.html";
       
        }
    }
    catch (error) {
        console.log(error);
    }    
        

    
};

//Funcion para editar el producto

let updateDataProducts = ()=>{
    // agregar datos a editar en los campos del formulario
    nameInput.value = ProductsUpdate.nombre;
    priceInput.value = ProductsUpdate.precio;
    stockInput.value = ProductsUpdate.stock;
    descripcionInput.value = ProductsUpdate.descripcion;
    imagen.src = ProductsUpdate.imagen;
    let product;
    // altenar el boton de crear y editar 

    let btnEdit = d.querySelector(".btn-update")
    btnCreate.classList.toggle("d-none");
    btnEdit.classList.toggle("d-none");
    //agregar evento al boton editar
    btnEdit.addEventListener("click", () => {
        product = {
            id : ProductsUpdate.id,
            nombre: nameInput.value,
            descripcion: descripcionInput.value,
            precio: priceInput.value,
            stock: stockInput.value,
            imagen: imagen.src
          
        };
        // borrar info de localStoage
        localStorage.removeItem("ProductEditar");
        // pasar los datos del prodecto a la funcion 
        sendUpdateProduct (product);
});
};

//Funcion para realizar la peticion al servidor

let sendUpdateProduct = async (pro)=> {
    let url = "http://localhost/backend-apiCrud/productos"; // Corregí "ulr" a "url"
    try {
        let respuesta = await fetch(url,{
            method: "PUT",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(pro)
        });
        if (respuesta.status === 406){
            alert("Los datos enviados no son admitidos");

        }else{
            let mensaje = await respuesta.json();
            alert(mensaje.message);       
            location.href = "../listado-pro.html";
       
        }
    }
    catch (error) {
        console.log(error);
    }    
}